:- module(app_proylcc, 
	[]).
:- use_module(library(pengines)).

:- pengine_application(proylcc).
:- use_module(proylcc:proylcc).
:- use_module(proylcc:init).